import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';

export default (models) => {
  const { Authentication } = models;
  const SALT_ROUNDS = 10;

  // ================= REGISTER =================
const register = async (request, h) => {
  try {
    const { username, password, id_admin, id_alumni } = request.payload;

    /* ================= VALIDASI EMAIL ================= */
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(username)) {
      return h.response({ error: "Format email tidak valid" }).code(400);
    }

    /* ================= CEK USER EXIST ================= */
    const existingUser = await Authentication.findOne({ where: { username } });
    if (existingUser) {
      return h.response({ error: "Email sudah terdaftar" }).code(400);
    }

    /* ================= VALIDASI PASSWORD ================= */
    if (!password || password.length < 6) {
      return h.response({ error: "Password minimal 6 karakter" }).code(400);
    }

    /* ================= VALIDASI ROLE ================= */
    if (id_admin && id_alumni) {
      return h.response({
        error: "User tidak boleh memiliki dua role"
      }).code(400);
    }

    if (!id_admin && !id_alumni) {
      return h.response({
        error: "Role tidak valid"
      }).code(400);
    }

    const role = id_admin ? 'admin' : 'alumni';

    /* ================= HASH PASSWORD ================= */
    const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);

    /* ================= CREATE USER ================= */
    const newUser = await Authentication.create({
      username,
      password: hashedPassword,
      role,                     
      id_admin: id_admin || null,
      id_alumni: id_alumni || null
    });

    return h.response({
      success: true,
      message: "Register berhasil",
      user: {
        id_user: newUser.id_user,
        username: newUser.username,
        role: newUser.role
      }
    }).code(201);

  } catch (err) {
    console.error("REGISTER ERROR:", err);
    return h.response({ error: err.message }).code(500);
  }
};

  // ================= LOGIN =================
  const login = async (request, h) => {
    try {
      const { username, password } = request.payload;

      const user = await Authentication.findOne({ where: { username } });
      if (!user) {
        return h.response({ error: "Akun tidak ditemukan" }).code(404);
      }

      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return h.response({ error: "Password salah" }).code(400);
      }

      // ================= GENERATE JWT =================
      const token = jwt.sign(
        {
          id_user: user.id_user,
          username: user.username,
          id_admin: user.id_admin,
          id_alumni: user.id_alumni
        },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRES_IN || '1d' }
      );

      return h.response({
        success: true,
        message: "Login berhasil",
        token,
        user: {
          id_user: user.id_user,
          username: user.username,
          id_admin: user.id_admin,
          id_alumni: user.id_alumni,
          role: user.role
        }
      });

    } catch (err) {
      console.error("LOGIN ERROR:", err);
      return h.response({ error: err.message }).code(500);
    }
  };

  
  // ------------------ CHANGE PASSWORD ------------------
  const changePassword = async (request, h) => {
    try {
      const { id_user, old_password, new_password } = request.payload;

      // VALIDASI
      if (!id_user || !old_password || !new_password) {
        return h.response({
          error: 'Semua field wajib diisi'
        }).code(400);
      }

      if (new_password.length < 6) {
        return h.response({
          error: 'Password baru minimal 6 karakter'
        }).code(400);
      }

      // CARI USER
      const user = await Authentication.findByPk(id_user);
      if (!user) {
        return h.response({
          error: 'User tidak ditemukan'
        }).code(404);
      }

      // CEK PASSWORD LAMA
      const match = await bcrypt.compare(old_password, user.password);
      if (!match) {
        return h.response({
          error: 'Password lama salah'
        }).code(400);
      }

      // HASH PASSWORD BARU
      const hashedPassword = await bcrypt.hash(new_password, SALT_ROUNDS);

      // UPDATE PASSWORD
      await user.update({
        password: hashedPassword
      });

      return h.response({
        success: true,
        message: 'Password berhasil diperbarui'
      });

    } catch (err) {
      console.error(err);
      return h.response({ error: err.message }).code(500);
    }
  };

// ================= LIST USER =================
  const listUsers = async (request, h) => {
    try {
      const users = await Authentication.findAll({
        attributes: [
          'id_user',
          'username',
          'id_admin',
          'id_alumni'
        ],
        order: [['id_user', 'ASC']]
      });

      return h.response({
        success: true,
        total: users.length,
        data: users
      });

    } catch (err) {
      console.error(err);
      return h.response({ error: err.message }).code(500);
    }
  };

  // ------------------ UPDATE EMAIL / USERNAME ------------------
  const updateUsername = async (request, h) => {
    try {
      const { id } = request.params;
      const { username } = request.payload;

      // 1. Validasi input
      if (!username) {
        return h.response({ error: 'Username tidak boleh kosong' }).code(400);
      }

      // 2. Validasi format email
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(username)) {
        return h.response({ error: 'Format email tidak valid' }).code(400);
      }

      // 3. Cari user
      const user = await Authentication.findByPk(id);
      if (!user) {
        return h.response({ error: 'User tidak ditemukan' }).code(404);
      }

      // 4. Cek duplikasi email (kecuali dirinya sendiri)
      const exist = await Authentication.findOne({
        where: { username }
      });

      if (exist && exist.id_user !== user.id_user) {
        return h.response({ error: 'Email sudah digunakan' }).code(409);
      }

      // 5. Update username
      await user.update({ username });

      return h.response({
        success: true,
        message: 'Email berhasil diperbarui',
        user: {
          id_user: user.id_user,
          username: user.username
        }
      });

    } catch (err) {
      console.error(err);
      return h.response({ error: err.message }).code(500);
    }
  };

  return { register, login, changePassword, listUsers, updateUsername};
};
